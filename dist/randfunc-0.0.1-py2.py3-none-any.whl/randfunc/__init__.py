from .about import __version__
__version__  # Silence unused import warning.
